# CÁCH DÙNG NHÂN VIÊN CONTENT

Mở Terminal → `cd ~/phong-marketing-ai` → gõ `claude` → ra lệnh bằng tiếng Việt thường.

## Câu lệnh mẫu — copy dùng ngay

| Việc | Gõ vào Claude Code |
|---|---|
| Research đầu tháng | `/nhan-vien-content research thị trường và đối thủ cho sản phẩm của tôi, trả bảng insight` |
| Lên lịch tuần | `/nhan-vien-content lên content calendar tuần sau, 6 bài, tôi duyệt trước khi viết` |
| Viết 1 bài | `/nhan-vien-content viết bài NÓNG chốt ưu đãi cuối tháng theo calendar` |
| Viết cả tuần | `/nhan-vien-content viết hết các bài trong calendar tuần này cho tôi duyệt một lượt` |
| Hẹn giờ đăng | `/nhan-vien-content các bài tôi vừa duyệt — hẹn giờ đăng theo đúng calendar` |
| Sửa giọng | `bài 3 nghe cứng quá, viết lại thân mật hơn` (nói tự nhiên, nó hiểu) |

## Nhịp làm việc gợi ý
- **Đầu tháng:** research 1 lần (30 phút của nó, 0 phút của bạn).
- **Chủ nhật:** lên calendar + viết cả tuần → bạn duyệt một lượt → hẹn giờ hết.
- **Trong tuần:** chỉ can thiệp khi có việc đột xuất (flash sale, phản hồi trend).

## Lưu ý
- Nó CHỈ đăng sau khi bạn nói rõ "duyệt, đăng đi". Trả bài xong nó luôn chờ.
- Số liệu trong bài chỉ lấy từ mục 5 hồ sơ — muốn nó nói "đã bán 1.000 đơn" thì phải ghi số đó
  (kèm nguồn) vào hồ sơ trước.
- Bài nó viết vẫn cần bạn đọc lại — bạn là giám đốc, nó là nhân viên.
