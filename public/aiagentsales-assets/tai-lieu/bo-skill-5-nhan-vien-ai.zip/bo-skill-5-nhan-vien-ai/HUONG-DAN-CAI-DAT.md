# HƯỚNG DẪN CÀI ĐẶT — PHÒNG MARKETING 5 NHÂN VIÊN AI

> Bộ này gồm **5 skill Claude Code** — mỗi skill là một nhân viên AI làm việc thật trên máy của bạn:
> đọc file, viết bài, gọi API chính thức của Meta, xuất báo cáo. Điều khiển hoàn toàn bằng tiếng Việt.
>
> **Chỉ dùng công cụ CHÍNH QUY:** API chính thức của Meta (Graph API / Marketing API),
> MCP connector chính thức của Meta Ads và TikTok Ads, Telegram Bot API, Google Sheet. Tuyệt đối không token lậu, không tool chui — tài khoản của bạn được an toàn.

## Bước 0 — Thứ bạn cần có trước

| Thứ cần | Ở đâu | Bắt buộc? |
|---|---|---|
| Máy tính Mac hoặc Windows | — | ✅ |
| Tài khoản Claude (gói Pro trở lên) | claude.ai | ✅ |
| Fanpage bạn là quản trị viên | facebook.com | ✅ |
| Token Graph API của page | Xem Bước 3 | ✅ cho đăng bài/đọc tin |
| Tài khoản quảng cáo Meta / TikTok | business.facebook.com · ads.tiktok.com | Chỉ cần cho NV Quảng Cáo (kết nối MCP ở Bước 3b) |
| Bot Telegram (miễn phí) | @BotFather trên Telegram | Chỉ cần cho NV Báo Cáo |

## Bước 1 — Cài Claude Code

Mở **Terminal** (Mac: Cmd+Space gõ "Terminal" · Windows: cài từ claude.com/claude-code) rồi chạy:

```
npm install -g @anthropic-ai/claude-code
```

Chưa có npm thì cài Node.js trước tại **nodejs.org** (bấm nút LTS, cài như phần mềm thường).
Xong, gõ `claude` trong Terminal — lần đầu nó mở trình duyệt cho bạn đăng nhập tài khoản Claude. Đăng nhập xong là Claude Code sẵn sàng.

## Bước 2 — Tạo văn phòng làm việc

```
mkdir -p ~/phong-marketing-ai && cd ~/phong-marketing-ai
```

Chép vào thư mục này:
1. Thư mục `ho-so-ban-hang/` (có file `HO-SO-BAN-HANG.md`) → **điền hết thông tin sản phẩm của bạn** theo hướng dẫn trong file. Đây là bộ não chung: điền sai thì cả 5 nhân viên làm sai.
2. Cả 5 thư mục skill vào `~/phong-marketing-ai/.claude/skills/`:

```
mkdir -p ~/phong-marketing-ai/.claude/skills
cp -R nhan-vien-content nhan-vien-video nhan-vien-quang-cao nhan-vien-chot-don nhan-vien-cskh-bao-cao ~/phong-marketing-ai/.claude/skills/
```

## Bước 3 — Lấy token Graph API chính thức của page (KHÔNG phải token lậu)

Token này do chính Meta cấp cho bạn, qua trang dành cho nhà phát triển của Meta:

1. Vào **developers.facebook.com** → đăng nhập bằng tài khoản Facebook quản lý page → **My Apps → Create App** → chọn loại **Business** → đặt tên tuỳ ý (ví dụ "Phong Marketing AI").
2. Trong app, mở **Tools → Graph API Explorer**.
3. Khung bên phải: chọn app vừa tạo → **User or Page** chọn page của bạn → **Permissions** thêm:
   `pages_show_list` · `pages_read_engagement` · `pages_manage_posts` · `pages_read_user_content` · `pages_manage_engagement` · `pages_messaging`. (Token này KHÔNG dùng cho quảng cáo — NV Quảng Cáo đi qua kết nối MCP ở Bước 3b.)
4. Bấm **Generate Access Token** → Meta hiện cửa sổ xin phép → đồng ý → copy chuỗi token.
5. Token Explorer chỉ sống ~1-2 giờ. Đổi sang token dài hạn: mở **Tools → Access Token Debugger**, dán token vào, bấm **Extend Access Token** → được token ~60 ngày. (Trong buổi học có video thao tác từng bước.)

Lưu token vào file `.env` trong văn phòng — chạy lệnh này (thay chuỗi thật của bạn vào):

```
cd ~/phong-marketing-ai && printf 'FB_PAGE_ID=SỐ_PAGE_ID\nFB_PAGE_TOKEN=DÁN_TOKEN_VÀO_ĐÂY\n' > .env
```

⚠️ **Luật giữ token:** file `.env` không gửi cho ai, không chụp màn hình, không dán vào chat công khai. Nhân viên AI được dạy chỉ đọc gián tiếp, không bao giờ in token ra màn hình.

## Bước 3b — Kết nối MCP quảng cáo (chỉ cần cho NV Quảng Cáo)

NV Quảng Cáo chạy Facebook Ads và TikTok Ads qua **MCP connector CHÍNH THỨC** do chính Meta và
TikTok phát hành — bạn đăng nhập OAuth bằng tài khoản của mình, không phải dán token thủ công:

1. Vào **claude.ai → Settings (Cài đặt) → Connectors (Trình kết nối)**.
2. Tìm **"Meta Ads"** → bấm **Connect** → đăng nhập Facebook có quyền trên tài khoản quảng cáo →
   đồng ý cấp quyền.
3. Tìm **"TikTok Ads"** → bấm **Connect** → đăng nhập TikTok Business → đồng ý cấp quyền.
4. Kết nối xong, mở phiên Claude Code MỚI (cùng tài khoản Claude) — nhân viên sẽ tự thấy các
   tool quảng cáo. Thử: `/nhan-vien-quang-cao đọc số ads hôm qua`.

Chỉ chạy Facebook thì kết nối mỗi Meta Ads là đủ; connector nào không dùng thì đừng kết nối.

## Bước 4 — Chạy thử nhân viên đầu tiên

```
cd ~/phong-marketing-ai && claude
```

Trong Claude Code, gõ thử:

> **/nhan-vien-content viết giúp 1 bài đăng giới thiệu sản phẩm cho tuần này**

Nhân viên sẽ tự đọc `HO-SO-BAN-HANG.md`, hỏi lại nếu hồ sơ còn chỗ trống, rồi trả bài viết cho bạn duyệt. Thấy nó trả lời đúng sản phẩm CỦA BẠN (không phải ví dụ mẫu) là cài đúng.

## Bước 5 — (Tuỳ chọn) Bot Telegram nhận báo cáo sáng

1. Mở Telegram, tìm **@BotFather** → gõ `/newbot` → đặt tên → nhận **bot token**.
2. Nhắn 1 tin bất kỳ cho bot của bạn, rồi mở trình duyệt vào `https://api.telegram.org/bot<TOKEN>/getUpdates` → tìm số `"chat":{"id":...}` — đó là **chat id** của bạn.
3. Thêm 2 dòng vào `.env`: `TELEGRAM_BOT_TOKEN=...` và `TELEGRAM_CHAT_ID=...`

## Xử lý lỗi hay gặp

| Triệu chứng | Nguyên nhân | Cách sửa |
|---|---|---|
| `command not found: claude` | npm cài chưa xong / chưa mở Terminal mới | Cài lại Bước 1, đóng mở Terminal |
| Nhân viên báo "không thấy hồ sơ" | Chạy `claude` ngoài thư mục văn phòng | Luôn `cd ~/phong-marketing-ai` trước |
| Gõ `/nhan-vien-...` không hiện skill | Skill chưa nằm đúng `.claude/skills/` | Kiểm tra lại Bước 2, mỗi skill phải có file `SKILL.md` |
| API báo lỗi 190 | Token hết hạn (~60 ngày) | Làm lại Bước 3 lấy token mới |
| API báo thiếu quyền (#200) | Lúc tạo token thiếu permission | Làm lại Bước 3, tick đủ quyền |
| NV Quảng Cáo báo "không thấy tool ads" | Chưa kết nối MCP connector | Làm Bước 3b, rồi mở phiên Claude Code mới |

---
*Bộ skill thuộc khoá AI Agent Sales — vieaiedu.vn/aiagentsales · Long Nam*
