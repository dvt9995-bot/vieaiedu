# CÁCH DÙNG NHÂN VIÊN VIDEO

Chuẩn bị: bỏ 3-8 ảnh sản phẩm (ảnh thật, nét) vào thư mục `tu-lieu/` trong văn phòng.

## Câu lệnh mẫu

| Việc | Gõ vào Claude Code |
|---|---|
| Video bán hàng | `/nhan-vien-video dựng video bán hàng 20 giây từ ảnh trong tu-lieu/, kịch bản cho tôi duyệt trước` |
| Video ưu đãi | `/nhan-vien-video video 15 giây cho flash sale cuối tuần, nhấn mạnh giảm còn 499k` |
| Sửa video | `chữ cảnh 2 nhỏ quá, phóng to lên và đổi màu vàng` |
| Đăng Reels | `video này duyệt rồi, đăng Reels lên page với caption như đã soạn` |

## Nhịp làm việc gợi ý
- Mỗi tuần 2-3 video là đủ nuôi kênh; ảnh chụp mới mỗi lô hàng để video không lặp.
- Video ads (chạy tiền) nên làm 2-3 bản khác nhau cho NV Quảng Cáo thử — cái nào rẻ tin nhắn thì giữ.

## Lưu ý
- Cần cài `ffmpeg` (miễn phí) — nhân viên sẽ tự kiểm và hướng dẫn nếu máy chưa có.
- Nó dựng xong LUÔN tự soi khung hình kiểm lỗi trước, rồi mới đưa bạn duyệt — nhưng mắt bạn vẫn là
  cửa cuối.
- TikTok/YouTube nó giao file + caption để bạn đăng tay (đăng tự động cần nối thêm API riêng —
  học ở buổi 2 của khoá).
