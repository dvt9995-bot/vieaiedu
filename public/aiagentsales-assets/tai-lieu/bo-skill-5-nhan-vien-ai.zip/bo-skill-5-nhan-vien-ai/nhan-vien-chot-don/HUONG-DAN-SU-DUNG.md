# CÁCH DÙNG NHÂN VIÊN TƯ VẤN & CHỐT ĐƠN

## Câu lệnh mẫu

| Việc | Gõ vào Claude Code |
|---|---|
| Dọn comment + inbox | `/nhan-vien-chot-don quét comment và inbox mới, soạn trả lời cho tôi duyệt` |
| Gửi loạt đã duyệt | `các câu trả lời ok hết, gửi đi` |
| Xem đơn | `/nhan-vien-chot-don hôm nay có mấy đơn mới, đơn nào đang treo?` |
| Cuối ngày | `/nhan-vien-chot-don chốt sổ hôm nay, cái gì cần tôi xử tay?` |

## Hai chế độ — bạn chọn khi mới dùng
1. **duyệt-từng-tin (mặc định, khuyên dùng 2 tuần đầu):** nó soạn hết, bạn liếc bảng rồi gật một
   lần. Mỗi phiên 5-10 phút của bạn thay vì cả tiếng tự gõ.
2. **tự-gửi:** khi bạn đã tin nó trả lời đúng ý — nó tự gửi câu thường (giá/ship/chính sách),
   vẫn chừa lại khiếu nại và câu khó cho bạn. Bật bằng cách nói:
   `từ giờ chế độ tự-gửi cho câu hỏi thường, còn lại vẫn chờ tôi`.

## Nhịp gợi ý
Chạy 2-3 lần/ngày (sáng - trưa - tối). Muốn tự chạy theo giờ, xem phần đặt lịch trong hướng dẫn
NV Báo Cáo — cùng một cách.

## Lưu ý
- Sổ đơn nằm ở `so-don/don-hang.csv` — mở bằng Excel/Google Sheet được luôn.
- Nó KHÔNG nhắn được khách đã im quá 24 giờ (luật của Meta, không phải nó lười) — danh sách đó
  nó giao bạn nhắn Zalo/gọi điện.
- Comment khách để SĐT: nó tự ẨN sau khi ghi đơn — kẻo đối thủ "hớt" mất khách của bạn.
