# CÁCH DÙNG NHÂN VIÊN CSKH & BÁO CÁO

## Câu lệnh mẫu

| Việc | Gõ vào Claude Code |
|---|---|
| Báo cáo sáng | `/nhan-vien-cskh-bao-cao làm báo cáo sáng, gửi Telegram cho tôi` |
| Chăm khách cũ | `/nhan-vien-cskh-bao-cao khách nào đến hạn chăm, soạn tin sẵn cho tôi` |
| Tổng kết tuần | `/nhan-vien-cskh-bao-cao tổng kết tuần + 3 đề xuất tối ưu` |

## Báo cáo TỰ ĐỘNG mỗi sáng 7h (không cần mở máy gõ lệnh)

Gõ một lần trong Terminal:
```
crontab -e
```
rồi thêm dòng (bấm i để gõ, Esc + :wq để lưu):
```
0 7 * * * cd ~/phong-marketing-ai && claude -p "/nhan-vien-cskh-bao-cao làm báo cáo sáng và gửi Telegram" --dangerously-skip-permissions
```
Từ mai, 7h sáng báo cáo tự hiện trong Telegram của bạn. Muốn tắt: `crontab -e` xoá dòng đó.
(Máy phải đang bật lúc 7h. Cờ skip-permissions chỉ dùng cho lệnh đọc-số-gửi-báo-cáo này.)

## Đọc báo cáo thế nào cho nhanh
- Mục 5 "việc cần bạn quyết" là mục quan trọng nhất — xử nó trước.
- Con số nào nó ghi "chưa đo được" nghĩa là nguồn đó chưa nối (ví dụ chưa điền token ads) — không
  phải nó quên.

## Lưu ý
- Nó chỉ SOẠN tin chăm khách cũ, bạn là người bấm gửi (Zalo/SĐT là kênh cá nhân của bạn với khách).
- Khách nào đã nói "đừng nhắn nữa" — đánh dấu KHONG_LAM_PHIEN vào sổ đơn là nó tự loại vĩnh viễn.
