# CHUỖI LỆNH MARKETING API — ĐƯỜNG DỰ PHÒNG khi chưa có MCP (chỉ Facebook)

> Đường chính là MCP connector Meta Ads / TikTok Ads (xem SKILL.md mục 0). File này chỉ dùng
> khi chủ chưa kết nối MCP — vẫn là Marketing API chính thức, cần FB_AD_ACCOUNT_ID + FB_ADS_TOKEN
> (token có ads_read · ads_management) trong .env.

> File tham chiếu cho nhân viên AI. Mỗi bước phải đọc `id` trong JSON trả về rồi mới sang bước
> sau — thiếu id là dừng, báo lỗi, không đoán.

```bash
ACT_ID=$(grep '^FB_AD_ACCOUNT_ID=' .env | cut -d= -f2-)
TOKEN=$(grep '^FB_ADS_TOKEN=' .env | cut -d= -f2-)
PAGE_ID=$(grep '^FB_PAGE_ID=' .env | cut -d= -f2-)
```

## Tầng 1 — Campaign (PAUSED)

```bash
curl -s -X POST "https://graph.facebook.com/v21.0/${ACT_ID}/campaigns" \
  --data-urlencode "name=[SP] San pham - Tin nhan - 2026-08" \
  --data-urlencode "objective=OUTCOME_ENGAGEMENT" \
  --data-urlencode "status=PAUSED" \
  --data-urlencode "special_ad_categories=[]" \
  --data-urlencode "access_token=${TOKEN}"
# → {"id":"CAMPAIGN_ID"}
```

Mục tiêu khác: bán trên web có pixel → `OUTCOME_SALES` · tìm lead form → `OUTCOME_LEADS`.
⚠️ Sản phẩm tín dụng/nhà đất/việc làm/chính trị phải khai `special_ad_categories` tương ứng —
khai sai là tài khoản ăn gậy.

## Tầng 2 — Ad set (ngân sách × đơn vị nhỏ nhất của tiền tệ; VND không có cent nên 200000 = 200k)

```bash
curl -s -X POST "https://graph.facebook.com/v21.0/${ACT_ID}/adsets" \
  --data-urlencode "name=Rong VN 22-45" \
  --data-urlencode "campaign_id=${CAMPAIGN_ID}" \
  --data-urlencode "daily_budget=200000" \
  --data-urlencode "billing_event=IMPRESSIONS" \
  --data-urlencode "optimization_goal=CONVERSATIONS" \
  --data-urlencode "destination_type=MESSENGER" \
  --data-urlencode "promoted_object={\"page_id\":\"${PAGE_ID}\"}" \
  --data-urlencode "targeting={\"geo_locations\":{\"countries\":[\"VN\"]},\"age_min\":22,\"age_max\":45}" \
  --data-urlencode "status=PAUSED" \
  --data-urlencode "access_token=${TOKEN}"
# → {"id":"ADSET_ID"}
```

Nhóm sở thích: thêm vào targeting `"flexible_spec":[{"interests":[{"id":"...","name":"..."}]}]`
(tra id sở thích: `GET /search?type=adinterest&q=từ+khoá`).

## Tầng 3 — Creative từ bài ĐÃ ĐĂNG trên page (tận dụng tương tác thật)

```bash
curl -s -X POST "https://graph.facebook.com/v21.0/${ACT_ID}/adcreatives" \
  --data-urlencode "name=Creative bai X" \
  --data-urlencode "object_story_id=${PAGE_ID}_${POST_ID}" \
  --data-urlencode "access_token=${TOKEN}"
# → {"id":"CREATIVE_ID"}
# Video Reels: lấy POST_ID của bài video đã đăng; không dựng creative từ file rời khi đã có bài sống.
```

## Tầng 4 — Ad (vẫn PAUSED)

```bash
curl -s -X POST "https://graph.facebook.com/v21.0/${ACT_ID}/ads" \
  --data-urlencode "name=Ad bai X - Rong" \
  --data-urlencode "adset_id=${ADSET_ID}" \
  --data-urlencode "creative={\"creative_id\":\"${CREATIVE_ID}\"}" \
  --data-urlencode "status=PAUSED" \
  --data-urlencode "access_token=${TOKEN}"
```

## Nghiệm thu cả chuỗi

```bash
curl -s -G "https://graph.facebook.com/v21.0/${CAMPAIGN_ID}" \
  --data-urlencode "fields=name,status,adsets{name,status,daily_budget,ads{name,status}}" \
  --data-urlencode "access_token=${TOKEN}"
```

Mọi status phải là PAUSED. Báo chủ danh sách + chờ lệnh bật. Bật:
`POST /{id}` với `status=ACTIVE` — làm từ ad → adset → campaign, xác nhận lại từng tầng.

## Mã lỗi hay gặp

| Mã | Nghĩa | Xử lý |
|---|---|---|
| 190 | token hết hạn | làm lại bước lấy token trong HUONG-DAN-CAI-DAT.md |
| #200 | thiếu quyền | token thiếu ads_management, tạo lại |
| #100 param | sai tham số | đọc message của Meta, thường sai định dạng targeting/budget |
| 1885557 | không promote được bài dạng này | tạo creative từ video_id thay vì object_story_id |
| #2 tạm thời | lỗi phía Meta | chờ 5 phút thử lại, quá 3 lần thì báo chủ |
