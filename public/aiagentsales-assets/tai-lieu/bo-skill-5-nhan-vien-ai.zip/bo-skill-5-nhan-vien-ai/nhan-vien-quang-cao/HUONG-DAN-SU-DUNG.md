# CÁCH DÙNG NHÂN VIÊN QUẢNG CÁO ⭐

Nhân viên "ra đơn" — và cũng là nhân viên ĐỤNG TIỀN, nên có luật riêng: **nó chỉ đề xuất,
bạn là người gật.** Không có chuyện nó tự tiêu tiền của bạn.

## Cần kết nối trước (một lần, ~5 phút — xem HUONG-DAN-CAI-DAT.md Bước 3b)

Nhân viên này chạy quảng cáo qua **MCP connector CHÍNH THỨC** của hai nền tảng — bạn đăng nhập
bằng chính tài khoản quảng cáo của mình, không phải đưa token cho ai:

- **Meta Ads** — quảng cáo Facebook/Instagram
- **TikTok Ads** — quảng cáo TikTok

Kết nối tại **claude.ai → Settings → Connectors** → tìm tên connector → Connect → đăng nhập.
Kết nối xong thì cả claude.ai lẫn Claude Code (cùng tài khoản) đều dùng được.

## Câu lệnh mẫu

| Việc | Gõ vào Claude Code |
|---|---|
| Đọc số mỗi sáng | `/nhan-vien-quang-cao đọc số ads hôm qua cả Facebook lẫn TikTok, báo cáo dễ hiểu` |
| Lên chiến dịch FB | `/nhan-vien-quang-cao đề xuất cấu trúc chiến dịch tin nhắn Facebook, ngân sách 300k/ngày` |
| Lên chiến dịch TikTok | `/nhan-vien-quang-cao đề xuất chiến dịch TikTok cho video X, ngân sách 300k/ngày` |
| Duyệt & tạo | `cấu trúc ok, tạo đi nhưng để tắt hết cho tôi soát` |
| Bật chạy | `tôi soát rồi, bật chiến dịch` ← chỉ khi bạn gõ câu này tiền mới bắt đầu chạy |
| Tối ưu | `/nhan-vien-quang-cao ad nào lỗ thì đề xuất tắt, ad nào ngon đề xuất tăng ngân sách` |
| Tuần | `/nhan-vien-quang-cao tổng kết ads tuần này, cái gì đáng giữ cái gì bỏ` |

## Ba mức giá bạn phải chốt trước (ghi vào hồ sơ mục 6)
1. **Giá chấp nhận mỗi kết quả** (ví dụ: 30k/tin nhắn) — thước đo tắt/giữ của nó.
2. **Ngân sách trần mỗi ngày** — nó không bao giờ đề xuất vượt.
3. **Mức tăng tối đa mỗi lần** (mặc định 20-30%).

## Lưu ý
- Ngày nào cũng hỏi nó số liệu — ads bỏ 3 ngày không nhìn là đốt tiền.
- Chỉ số nó báo lấy thẳng từ connector chính thức của Meta/TikTok trên chính tài khoản bạn —
  không qua tool thứ ba nào.
- 2-3 ngày đầu chiến dịch số xấu là bình thường (máy học của nền tảng) — nó biết điều này và sẽ
  khuyên bạn đừng tắt vội.
- Video chạy TikTok phải là video DỌC 9:16 — video 3:4 sẽ bị hệ thống từ chối.
- Nó báo "không thấy tool ads" → connector chưa kết nối, làm lại Bước 3b rồi mở phiên Claude mới.
